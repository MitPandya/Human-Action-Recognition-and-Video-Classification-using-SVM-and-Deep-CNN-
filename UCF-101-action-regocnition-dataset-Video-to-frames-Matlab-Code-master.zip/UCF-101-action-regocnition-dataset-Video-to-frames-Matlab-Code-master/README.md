# UCF-101-action-regocnition-dataset-Video-to-frames-Matlab-Code
This contains the matlab code to covert video to frames for UCF-101 Action recognition dataset 3 Train/Test split as provided by UCF-101 website
